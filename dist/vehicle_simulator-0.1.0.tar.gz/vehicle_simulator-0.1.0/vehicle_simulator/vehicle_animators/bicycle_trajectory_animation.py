"""
Bicycle Trajectory Animation class
"""
import numpy as np
import matplotlib.pyplot as plt 
import matplotlib.animation as animation
from vehicle_simulator.vehicle_models.bicycle_model import BicycleModel
from vehicle_simulator.vehicle_controllers.bicycle_trajectory_tracker import BicycleTrajectoryTracker
from dataclasses import dataclass
from time import sleep

@dataclass
class TrajectoryData:
    location_data: np.ndarray
    velocity_data: np.ndarray
    acceleration_data: np.ndarray
    jerk_data: np.ndarray
    time_data: np.ndarray

    def __post_init__(self):
        location_dimension = np.shape(self.location_data)[0]
        velocity_dimension = np.shape(self.velocity_data)[0]
        acceleration_dimension = np.shape(self.acceleration_data)[0]
        jerk_dimension = np.shape(self.jerk_data)[0]
        location_length = np.shape(self.location_data)[1]
        velocity_length = np.shape(self.velocity_data)[1]
        acceleration_length = np.shape(self.acceleration_data)[1]
        jerk_length = np.shape(self.jerk_data)[1]
        time_length = len(self.time_data)
        if location_dimension != velocity_dimension or \
                velocity_dimension != acceleration_dimension or \
                acceleration_dimension != jerk_dimension:
            raise Exception("Trajectory data dimensions are not equal")
        if location_length != velocity_length or \
                velocity_length != acceleration_length or \
                acceleration_length != jerk_length or \
                jerk_length != time_length:
            raise Exception("Trajectory data lengths are not equal")

class BicycleTrajectoryAnimation:

    def __init__(self, margins = 5):
        self._margins = margins
                 
    def animate_trajectory_following(self, bicycle_model: BicycleModel, traj_tracker: BicycleTrajectoryTracker, 
                                     trajectory_data: TrajectoryData, sleep_time: float = 0):
        location_data = trajectory_data.location_data
        velocity_data = trajectory_data.velocity_data
        acceleration_data = trajectory_data.acceleration_data
        time_data = trajectory_data.time_data
        dt = time_data[1] - time_data[0]
        x_limits = np.array([np.min(location_data [0,:]) - self._margins, np.max(location_data [0,:]) + self._margins])
        y_limits = np.array([np.min(location_data [1,:]) - self._margins, np.max(location_data [1,:]) + self._margins])
        ## plotting

        fig = plt.figure()
        ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                            xlim=(x_limits[0],x_limits[1]), ylim=(y_limits[0],y_limits[1]))
        ax.grid()
        front_wheel_fig = plt.Polygon(bicycle_model.getFrontWheelPoints(),fc = 'k')
        back_wheel_fig = plt.Polygon(bicycle_model.getBackWheelPoints(),fc = 'k')
        body_fig = plt.Polygon(bicycle_model.getBodyPoints(),fc = 'g')
        desired_position_fig = plt.Circle((0, 0), radius=0.1, fc='r')

        time_text = ax.text(0.02, 0.95, '', transform=ax.transAxes)
        ax.plot(location_data[0,:],location_data[1,:])

        def init():
            #initialize animation
            ax.add_patch(front_wheel_fig)
            ax.add_patch(back_wheel_fig)
            ax.add_patch(body_fig)
            ax.add_patch(desired_position_fig)
            time_text.set_text('')
            return front_wheel_fig, back_wheel_fig, body_fig, desired_position_fig, time_text

        def animate(i):
            # propogate robot motion
            states = bicycle_model.getState() 
            t = time_data[i]
            position = location_data[:,i]
            velocity = velocity_data[:,i]
            acceleration = acceleration_data[:,i]
            desired_states = np.vstack((position, velocity, acceleration))
            vel_dot, delta_dot = traj_tracker.mpc_control_accel_input(states, desired_states)
            v_dot_hat, delta_dot_hat = bicycle_model.update_acceleration_motion_model(vel_dot, delta_dot, dt)
            front_wheel_fig.xy = bicycle_model.getFrontWheelPoints()
            back_wheel_fig.xy = bicycle_model.getBackWheelPoints()
            body_fig.xy = bicycle_model.getBodyPoints()
            desired_position_fig.center = (position[0],position[1])
   
            # update time
            sleep(sleep_time)
            time_text.set_text('time = %.1f' % t)

            return  front_wheel_fig, back_wheel_fig, body_fig,desired_position_fig, time_text
        animate(0)
        ani = animation.FuncAnimation(fig, animate, frames = np.size(time_data), 
                                    interval = dt*100, blit = True, init_func = init, repeat = False)
        plt.show()
        print("figure closed")
